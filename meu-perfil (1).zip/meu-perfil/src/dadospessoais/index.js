import { View, Text } from 'react-native'
import {styles} from './styles'


function Dados(){
  return(
    <View style={styles.area}>
      <Text style={[styles.textoPrincipal, styles.alinhaTexto]}>Dados Pessoais</Text>
      <Text>Francielly Almeida Gonçalves da Silva</Text>
    </View>
  )
}


export default Dados;
