import {StyleSheet} from 'react-native';


const styles = StyleSheet.create({
    textoPrincipal:{
        fontSize: 28,
        color: 'purple',
    },
    alinhaTexto:{
        textAlign: 'center'
    },
});


export {styles}